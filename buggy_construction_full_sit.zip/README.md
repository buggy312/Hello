# Buggy Construction — Full Website Bundle

Files:
- index.html
- about.html
- services.html
- contact.html
- styles.css
- script.js
- logo.svg
- business_card.svg

## How to publish on GitHub Pages

1. Create a GitHub account with username `buggy5429` (or choose a variation if taken).
2. Create a new repository named `buggy5429.github.io`.
3. Upload all files in this folder to the repository root.
4. Wait a minute; your site will be live at:
   `https://buggy5429.github.io/`

## Alternative: Netlify or Vercel
- Drag & drop the site folder to Netlify Drop to publish instantly.
- Upload to a Git repo and connect to Vercel for automatic deploys.

## Customization
I included sensible defaults:
- Business name: Buggy Construction
- Phone: +1 (215) 555-1234
- Email: buggy@example.com
- Service areas: Philly neighborhoods

If you want me to change any of the above (real phone, email, logo adjustments, add testimonials, SEO meta tags, or hook up a real form), tell me and I’ll edit the files and give you an updated ZIP.

