document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('year') && (document.getElementById('year').textContent = new Date().getFullYear());

  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.nav');
  if (toggle) {
    toggle.addEventListener('click', () => {
      const expanded = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!expanded));
      if (nav) nav.style.display = expanded ? '' : 'flex';
    });
  }

  // contact form: opens email client with message by default
  const form = document.getElementById('contact-form');
  const status = document.getElementById('form-status');
  if (form) {
    form.addEventListener('submit', function(e){
      e.preventDefault();
      status.textContent = 'Preparing message...';
      const name = form.name.value.trim();
      const email = form.email.value.trim();
      const phone = form.phone ? form.phone.value.trim() : '';
      const message = form.message.value.trim();
      if (!name || !email || !message) {
        status.textContent = 'Please complete all required fields.';
        return;
      }
      const body = message + '\n\n' + name + (phone ? '\n' + phone : '') + '\n' + email;
      const mailto = 'mailto:buggy@example.com?subject=' + encodeURIComponent('Website inquiry from ' + name) + '&body=' + encodeURIComponent(body);
      window.location.href = mailto;
      status.textContent = 'Opening your email client...';
    });
  }
});
